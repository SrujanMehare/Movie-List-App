package com.example.movieapp.data.network

import com.example.movieapp.data.Movie

data class TmdbMovieList(
    val Search: List<Movie>
)